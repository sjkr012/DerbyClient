/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package magicianagent;

import java.sql.*;
//import javax.swing.*;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.Timestamp;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;

import java.util.List;
import java.util.ArrayList;
/**
 *
 * @author sjkr012
 */
public class Reservation {
    private static final String url = "jdbc:derby://localhost:1527/MagicianJFrame";
    private static final String user = "sj";
    private static final String password = "11";
    
    private Connection connection = null;
    private PreparedStatement insertCustomer = null;
    private PreparedStatement insertBooking = null;
    //private PreparedStatement selectMagician = null;
    private PreparedStatement getFreeMagician = null;
    private PreparedStatement insertWaitingList = null;
    Statement waitingListDisplay = null;
    ResultSet waitResultSet = null;
    Statement magicianListDisplay = null;
    ResultSet magResultSet = null;
    Statement holidayListDisplay = null;
    ResultSet holiResultSet = null;
   
    
    public Reservation()
    {
        try
        {
            connection = DriverManager.getConnection(url, user, password);    
            
            
            insertCustomer = connection.prepareStatement("INSERT INTO CUSTOMERLIST (NAME) " + "VALUES (?)" );
            insertBooking = connection.prepareStatement("INSERT INTO BOOKINGLIST (CUSTOMERNAME, MAGICIANNAME, HOLIDAYNAME, PRIORITY)"
                    + "VALUES (?, ?, ?, ?) ");
            
            getFreeMagician = connection.prepareStatement("SELECT MAGICIANNAME FROM MAGICIANLIST WHERE MAGICIANNAME NOT IN (SELECT MAGICIANNAME from BOOKINGLIST WHERE HOLIDAYNAME = ?)");
            insertWaitingList = connection.prepareStatement("INSERT INTO WAITINGLIST (WAITINGCUSTOMER, PRIORITY, HOLIDAY)"
                   + "VALUES(?, ?, ?)"); 
            
            waitingListDisplay = connection.createStatement();
            waitResultSet = waitingListDisplay.executeQuery("SELECT WAITINGCUSTOMER, PRIORITY, HOLIDAY FROM WAITINGLIST");
            magicianListDisplay = connection.createStatement();
            magResultSet = magicianListDisplay.executeQuery("SELECT MAGICIANNAME FROM MAGICIANLIST");
            holidayListDisplay = connection.createStatement();
            holiResultSet = holidayListDisplay.executeQuery("SELECT HOLIDAYNAME FROM HOLIDAYLIST");
            
            
            
        }
        catch(SQLException sqlException)
        {
           JOptionPane.showMessageDialog(null, "there is an error");
           System.exit(1);
           
        }
        
    }
    
    public boolean addCustomer(String name)
    {
        boolean flag = false;
        try
        {
            insertCustomer.setString(1, name);
            flag = insertCustomer.execute();
        }
        catch( SQLException sqlException)
        {
            //sqlException.printStackTrace();
            close();        
        }
       return flag;
    }
    public boolean addBookingList(String custName, String magName, String holiName, Timestamp timestamp)
    {
        
        boolean flag2 = false;
        try
        {
            
            insertBooking.setString(1, custName);
            insertBooking.setString(2, magName);
            insertBooking.setString(3, holiName);
            insertBooking.setTimestamp(4, timestamp);
            flag2 = insertBooking.execute();
        }
        catch( SQLException sqlException)
        {
            close();        
        }
        return flag2;
    }
    public boolean addWaitingList(String name,Timestamp timestamp, String holiday)
    {
        boolean flag3 = false;
        try
        {
            insertWaitingList.setString(1, name);
            insertWaitingList.setTimestamp(2, timestamp);
            insertWaitingList.setString(3, holiday);
            flag3 = insertWaitingList.execute();
        }
        catch( SQLException sqlException)
        {
            close();
        }
        return flag3;
    }
    public List<Magician> getFreeMagician(String holiday)
    {
        ResultSet rst = null;
        List<Magician> results = null;
        
        try
        {
            getFreeMagician.setString(1, holiday);
            
            rst = getFreeMagician.executeQuery();
            results = new ArrayList<>();
            while(rst.next())
            {
                results.add( new Magician(rst.getString("MAGICIANNAME")));
            }
        }
        catch( SQLException sqlException)
        {
            
        }
        finally
        {
            try
            {
                rst.close();
            }
            catch( SQLException sqlException)
            {
                close();
            }
        }
        return results;
    }
    public void close()
    {
        try
        {
           connection.close();
        }
        catch( SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }

    
}
