/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package magicianagent;

/**
 *
 * @author sjkr012
 */


public class Holiday {
    private String holidayName;
    
    public Holiday() {
    }
    
    public Holiday(String holidayName)
    {
        setHolidayName( holidayName );
    }
    public void setHolidayName(String name)
    {
        holidayName = name;
    }
    public String getMagicianName()
    {
        return holidayName;
    }
}
