/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Magician1;

/**
 *
 * @author sjkr012
 */
public class ShowList {
    
    private String holidayName;
    private String customerName;
    private String magicianName;
    public ShowList(){
        
    }
    public ShowList(String name1, String name2, String name3)
    {
        setHolidayName( name1 );
        setMagicianName( name2 );
        setCustomerName( name3 );
    }
    public void setHolidayName(String name)
    {
        holidayName = name;
    }
    public String getHolidayName()
    {
        return holidayName;
    }
    public void setCustomerName(String name)
    {
        customerName = name;
    }
    public String getCustomerName()
    {
        return customerName;
    }
    public void setMagicianName(String name)
    {
        magicianName = name;
    }
    public String getMagicianName()
    {
        return magicianName;
    }
    
}
