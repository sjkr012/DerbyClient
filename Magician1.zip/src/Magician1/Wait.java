/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Magician1;

import java.sql.Timestamp;

/**
 *
 * @author sjkr012
 */
public class Wait {
    private String holidayName;
    private String customerName;
    private String magicianName;
    private Timestamp timeStamp;
    public Wait(){
        
    }
    public Wait(String name1, Timestamp time, String name2){
        
        setCustomerName( name1 );
        setTimestamp( time );
        setHolidayName( name2 );
    }
    public void setHolidayName(String name)
    {
        holidayName = name;
    }
    public String getHolidayName()
    {
        return holidayName;
    }
    public void setCustomerName(String name)
    {
        customerName = name;
    }
    public String getCustomerName()
    {
        return customerName;
    }
    public void setMagicianName(String name)
    {
        magicianName = name;
    }
    public String getMagicianName()
    {
        return magicianName;
    }
    public void setTimestamp(Timestamp time)
    {
        timeStamp = time;
    }
    public Timestamp getTimeStamp()
    {
        return timeStamp;
    }
}
