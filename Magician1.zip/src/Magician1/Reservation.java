/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Magician1;

import java.sql.*;
//import javax.swing.*;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.Timestamp;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;

import java.util.List;
import java.util.ArrayList;
import java.util.Calendar;
/**
 *
 * @author sjkr012
 */
public class Reservation {
    private static final String url = "jdbc:derby://localhost:1527/MagicianJFrame";
    private static final String user = "sj";
    private static final String password = "11";
    
    
    private Connection connection = null;
    
    private PreparedStatement insertCustomer = null;
    private PreparedStatement insertBooking = null;
    private PreparedStatement insertWaitingList = null;
    private PreparedStatement insertMagicianList = null;
    private PreparedStatement insertHolidayList = null;
    
    private PreparedStatement getFreeMagician = null;
    public PreparedStatement getHolidayList = null;
    public PreparedStatement getMagicianList = null;
    public PreparedStatement getWaitingList = null;
    public PreparedStatement getMagicianAllBookingList = null;
    private PreparedStatement getMagicianFromCancelCustomer = null;
    
    private PreparedStatement deleteMagician = null;
    private PreparedStatement deleteWaitingList = null;
    private PreparedStatement deleteBookingList = null;
    private PreparedStatement deleteCustomerList = null;
    private PreparedStatement deleteAllFromWaitingList = null;
    
    public PreparedStatement getMagicianName = null;
    public PreparedStatement getHolidayName = null;
    public PreparedStatement getCustomerName = null;
    
    
    private List< Magician > results;
    private List<AllBook> resultAllBook;
    private List<Wait> resultMag;
    private List<Wait> resultAllWaiting;
    
    private Wait currentWaitingEntry;
    private AllBook currentAllBookEntry;
    private Wait currentAllWaitingEntry;
    private Magician currentEntry;
    
    
    private int numberOfEntries2 = 0;
    private int currentEntryIndex2 = 0;
    private int numberOfEntries = 0;
    private int numberOfWaitingEntries = 0;
    private int currentEntryIndex;    

    
    public Reservation()
    {
        
        try
        {
            
            connection = DriverManager.getConnection(url, user, password);    
            
            insertCustomer = connection.prepareStatement("INSERT INTO CUSTOMERLIST (NAME) " + "VALUES (?)" );
            insertBooking = connection.prepareStatement("INSERT INTO BOOKINGLIST (CUSTOMERNAME, MAGICIANNAME, HOLIDAYNAME, PRIORITY)"
                    + "VALUES (?, ?, ?, ?) ");
            insertMagicianList = connection.prepareStatement("INSERT INTO MAGICIANLIST (MAGICIANNAME) " + "VALUES (?)");
            insertWaitingList = connection.prepareStatement("INSERT INTO WAITINGLIST (WAITINGCUSTOMER, PRIORITY, HOLIDAY)"
                   + "VALUES(?, ?, ?)");
            insertHolidayList = connection.prepareStatement("INSERT INTO HOLIDAYLIST (HOLIDAYNAME)" + "VALUES (?)");
            
            getFreeMagician = connection.prepareStatement("SELECT MAGICIANNAME FROM MAGICIANLIST WHERE MAGICIANNAME NOT IN (SELECT MAGICIANNAME from BOOKINGLIST WHERE HOLIDAYNAME = ?)");
            getMagicianAllBookingList = connection.prepareStatement("SELECT * FROM BOOKINGLIST WHERE MAGICIANNAME = ?");
            getMagicianFromCancelCustomer = connection.prepareStatement("SELECT MAGICIANNAME FROM BOOKINGLIST WHERE CUSTOMERNAME =? AND HOLIDAYNAME=?");
           
            getMagicianName = connection.prepareStatement("SELECT * FROM MAGICIANLIST");
            getHolidayName = connection.prepareStatement("SELECT * FROM HOLIDAYLIST");
            getCustomerName = connection.prepareStatement("SELECT * FROM CUSTOMERLIST");
    
            getWaitingList = connection.prepareStatement("SELECT * FROM WAITINGLIST");
            getHolidayList = connection.prepareStatement("SELECT CUSTOMERNAME, MAGICIANNAME FROM BOOKINGLIST WHERE HOLIDAYNAME =?");
            getMagicianList = connection.prepareStatement("SELECT CUSTOMERNAME, HOLIDAYNAME FROM BOOKINGLIST WHERE MAGICIANNAME = ?");    
            
            deleteMagician = connection.prepareStatement("DELETE FROM MAGICIANLIST WHERE MAGICIANNAME =?");
            deleteWaitingList = connection.prepareStatement("DELETE FROM WAITINGLIST WHERE WAITINGCUSTOMER = ? AND HOLIDAY = ? ");
            deleteBookingList = connection.prepareStatement("DELETE FROM BOOKINGLIST WHERE CUSTOMERNAME =? AND HOLIDAYNAME = ?");
            deleteCustomerList = connection.prepareStatement("DELETE FROM CUSTOMERLIST WHERE NAME =?");
            deleteAllFromWaitingList = connection.prepareStatement("DELETE FROM WAITINGLIST");
                    
        }
        catch(SQLException sqlException)
        {
           JOptionPane.showMessageDialog(null, "there is an error");
           sqlException.printStackTrace();
           System.exit(1);
           
        }
        
    }
    
    public boolean addCustomer(String name)
    {
        boolean flag = false;
        try
        {
            insertCustomer.setString(1, name);
            flag = insertCustomer.execute();
        }
        catch( SQLException sqlException)
        {
            sqlException.printStackTrace();        
        }
       return flag;
    }
    
    public boolean addBookingList(String custName, String magName, String holiName, Timestamp timestamp)
    {
        
        boolean flag2 = false;
        try
        {
            
            insertBooking.setString(1, custName);
            insertBooking.setString(2, magName);
            insertBooking.setString(3, holiName);
            insertBooking.setTimestamp(4, timestamp);
            flag2 = insertBooking.execute();
        }
        catch( SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return flag2;
    }
    public boolean addMagicianList(String name)
    {
        boolean flag4 = false;
        try
        {
            insertMagicianList.setString(1, name);
            flag4 = insertMagicianList.execute();
        }
        catch( SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        String mdisplay = "magician ' " + name + " ' is succesfully added";
        if(flag4 = true)
            JOptionPane.showMessageDialog(null, mdisplay);
        
        return flag4;
        
    }
    public boolean addWaitingList(String name,Timestamp timestamp, String holiday)
    {
        boolean flag3 = false;
        try
        {
            insertWaitingList.setString(1, name);
            insertWaitingList.setTimestamp(2, timestamp);
            insertWaitingList.setString(3, holiday);
            flag3 = insertWaitingList.execute();
        }
        catch( SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return flag3;
    }
    public boolean deleteCustomerList(String cname)
    {
        boolean flagC = false;
        try{
            deleteCustomerList.setString(1, cname);
            flagC = deleteCustomerList.execute();
        }
        catch( SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return flagC;
    }
    public boolean deleteMagician(String magician)
    {
        boolean flagM = false;
        try{
            deleteMagician.setString(1, magician);
            flagM = deleteMagician.execute();
        }
        catch( SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return flagM;
    }
    public List<Magician> getMagicianFromCancelCustomer(String cname, String hname)
    {
        ResultSet rst = null;
        List<Magician> results = null;
        
        try
        {
            getMagicianFromCancelCustomer.setString(1, cname);
            getMagicianFromCancelCustomer.setString(2, hname);
            
            rst = getMagicianFromCancelCustomer.executeQuery();
            results = new ArrayList<>();
            while(rst.next())
            {           
                results.add( new Magician(rst.getString("MAGICIANNAME")));
            }

        }
        catch( SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        finally
        {
            try
            {
                rst.close();
            }
            catch( SQLException sqlException)
            {
                sqlException.printStackTrace();
            }
        }
        return results;
    }
    public List<Book> getMagicianList(String magician)
    {   
        ResultSet rst = null;
        List<Book> results = null;
        
        try
        {
            getMagicianList.setString(1, magician);
            
            rst = getMagicianList.executeQuery();
            results = new ArrayList<>();
            while(rst.next())
            {           
                results.add( new Book(rst.getString("CUSTOMERNAME"),
                rst.getString("HOLIDAYNAME")));
            }

        }
        catch( SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        finally
        {
            try
            {
                rst.close();
            }
            catch( SQLException sqlException)
            {
                sqlException.printStackTrace();
            }
        }
        return results;
       
    }
    public List<AllBook> getMagicianAllBookingList(String magician)
    {
        ResultSet rst = null;
        List<AllBook> resultAll = null;
        
        try
        {
            getMagicianAllBookingList.setString(1, magician);
            
            rst = getMagicianAllBookingList.executeQuery();
            resultAll = new ArrayList<>();
            while(rst.next())
            {           
                resultAll.add( new AllBook(rst.getString("CUSTOMERNAME"),
                rst.getString("MAGICIANNAME"),
                rst.getString("HOLIDAYNAME"),
                rst.getTimestamp("PRIORITY")));
            }

        }
        catch( SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        finally
        {
            try
            {
                rst.close();
            }
            catch( SQLException sqlException)
            {
                sqlException.printStackTrace();
            }
        }
        return resultAll;
    }
    public boolean deleteAllFromWaitingList()
    {
        boolean flagA = false;
        try{
            flagA = deleteAllFromWaitingList.execute();
        }
        catch( SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return flagA;
    }
    public boolean deleteBookingList(String cname, String hname)
    {
        boolean flagB = false;
        try{
            deleteBookingList.setString(1, cname);
            deleteBookingList.setString(2, hname);
            flagB = deleteBookingList.execute();
        }
        catch( SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return flagB;
    }
    public boolean deleteWaitingList(String cname, String hname)
    {
        boolean flagW = false;
        try{
            deleteWaitingList.setString(1, cname);
            deleteWaitingList.setString(2, hname);
            flagW = deleteWaitingList.execute();
        }
        catch( SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return flagW;
    }
    public List<Wait> getWaitingList()
    {
        ResultSet rstWait = null;
        List<Wait> resultWait = null;
        
        try
        {
            
            rstWait = getWaitingList.executeQuery();
            resultWait = new ArrayList<>();
            while(rstWait.next())
            {
                resultWait.add( new Wait(rstWait.getString("WAITINGCUSTOMER"),
                rstWait.getTimestamp("PRIORITY"),
                rstWait.getString("HOLIDAY")));
            }

        }
        catch( SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        finally
        {
            try
            {
                rstWait.close();
            }
            catch( SQLException sqlException)
            {
                sqlException.printStackTrace();
            }
        }
        return resultWait;
    }
    
    public List<Magician> getFreeMagician(String holiday)
    {
        ResultSet rst = null;
        List<Magician> results = null;
        
        try
        {
            getFreeMagician.setString(1, holiday);
            
            rst = getFreeMagician.executeQuery();
            results = new ArrayList<>();
            while(rst.next())
            {           
                results.add( new Magician(rst.getString("MAGICIANNAME")));
            }

        }
        catch( SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        finally
        {
            try
            {
                rst.close();
            }
            catch( SQLException sqlException)
            {
                sqlException.printStackTrace();
            }
        }
        return results;
    }
    public void booking(String cnameText, String hcombo)
    {
        try
        {
           Timestamp currentTimestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());    
           boolean flag = addCustomer(cnameText);
           
           results = getFreeMagician(hcombo);
           numberOfEntries = results.size();
           if( numberOfEntries != 0)
           {
               currentEntryIndex = 0;
               currentEntry = results.get(currentEntryIndex);
               boolean flag2 = addBookingList(cnameText, currentEntry.getMagicianName() ,  hcombo, currentTimestamp );
               String c = "user ' " + cnameText + " ' is succesfully booked with ' " +  currentEntry.getMagicianName() + " '";
               if (flag2 = true)
                    JOptionPane.showMessageDialog(null, c);
           }
           else if (numberOfEntries == 0)
           {
               boolean flag3 = addWaitingList(cnameText, currentTimestamp, hcombo);
               if(flag3 = true)
                    JOptionPane.showMessageDialog(null, "user is added to Waiting List");
           }  
        }
        catch(Exception e)
        {
            close();
        }
    }
    public void deleteManageMagician(String magician)
    { 
        try
        {
           boolean flag = deleteMagician(magician);
           String deletion = "magician ' " + magician + " '  is successfully deleted"; 
           if(flag = true)
                JOptionPane.showMessageDialog(null, deletion);
               
           resultAllWaiting = getWaitingList();
           numberOfWaitingEntries = resultAllWaiting.size();
            
           resultAllBook = getMagicianAllBookingList(magician);
           numberOfEntries = resultAllBook.size();
           deleteAllFromWaitingList();
           for(int j = 0; j < numberOfWaitingEntries; j++)
           {   
                currentAllWaitingEntry = resultAllWaiting.get(j);
                for(int i = 0; i < numberOfEntries; i++)
                {
                    currentAllBookEntry = resultAllBook.get(i);       
                    boolean flagB = deleteBookingList(currentAllBookEntry.getCustomerName(), currentAllBookEntry.getHolidayName());
                    boolean flag3 = addWaitingList(currentAllBookEntry.getCustomerName(), currentAllBookEntry.getTimeStamp(), currentAllBookEntry.getHolidayName());

                    String display = "customer ' " + currentAllBookEntry.getCustomerName() + " ' booked on ' " + currentAllBookEntry.getHolidayName() + " ' is added to the WaitingList";
                    JOptionPane.showMessageDialog(null, display);

                }
                boolean flag3 = addWaitingList(currentAllWaitingEntry.getCustomerName(), currentAllWaitingEntry.getTimeStamp(), currentAllWaitingEntry.getHolidayName() );
                
           }
        }
        catch( Exception e)
        {
            close();
        }
    }
    public void addManageMagician(String magician)
    {
        try
        {
           
           resultMag = getWaitingList();
           numberOfEntries = resultMag.size();
           
           if( numberOfEntries != 0)
           {
               currentEntryIndex = 0;
               currentWaitingEntry = resultMag.get(currentEntryIndex);           
               boolean flag2 = addBookingList(currentWaitingEntry.getCustomerName(), magician ,  currentWaitingEntry.getHolidayName(), currentWaitingEntry.getTimeStamp());
               boolean flagW = deleteWaitingList(currentWaitingEntry.getCustomerName(), currentWaitingEntry.getHolidayName());
               
               String display = "Customer ' " + currentWaitingEntry.getCustomerName() + " ' is scheduled with " + magician + " on " + currentWaitingEntry.getHolidayName();
               JOptionPane.showMessageDialog(null, display);
                
           }
        }
        catch( Exception e)
        {
            close();
        }
    }

    public void cancelReservation(String cname, String hname)
    {
       try{
            results = getMagicianFromCancelCustomer(cname, hname);
            numberOfEntries2 = results.size();
            if( numberOfEntries2 != 0)
            {
                currentEntryIndex2 = 0;
                currentEntry = results.get(currentEntryIndex2);
                addManageMagician(currentEntry.getMagicianName());
            }
            boolean flagB = deleteBookingList(cname, hname);
            boolean flagW = deleteWaitingList(cname, hname);
            boolean flagC = deleteCustomerList(cname);
            if(flagB = true)
            {

                      JOptionPane.showMessageDialog(null, "successfully cancelled the reservation");
            }
       }
       catch( Exception e)
        {
            close();
            JOptionPane.showMessageDialog(null, "there is an error");
        }
       
        
    }
    public boolean addManageHolidayList(String holiday)
    {
        boolean flagH = false;
        try{
                insertHolidayList.setString(1, holiday);
                flagH = insertHolidayList.execute();
                
                if(flagH = true)
                    JOptionPane.showMessageDialog(null, "successfully added");
        }
        catch( SQLException sqlException)
        {
            sqlException.printStackTrace();
            JOptionPane.showMessageDialog(null, "it is a duplicate value");
        }
        return flagH;
        
    }
    
    
    public void close()
    {
        try
        {
           connection.close();
        }
        catch( SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
    
}
