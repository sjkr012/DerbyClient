/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Magician1;

/**
 *
 * @author sjkr012
 */
public class Magician {
        
    private String magicianName;
    
    public Magician() {
    }
    
    public Magician(String magicianName)
    {
        setMagicianName( magicianName );
    }
    public void setMagicianName(String name)
    {
        magicianName = name;
    }
    public String getMagicianName()
    {
        return magicianName;
    }
    
    
}
